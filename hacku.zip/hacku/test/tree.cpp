#include <string>
#include <iostream>
#include <vector>
#include <cstdio>

using namespace std;

class node {
	public:
	string text;
	vector <node *> children;
	node * parent;
};

char a[100000];
string s;

void dfs(node * u, int depth) {
	for(int i = 0; i < depth; i ++)
		printf("||");
	cout << u -> text << "\n";
	//printf("Children (%d): \n", (u -> children).size());
	for(int i = 0; i < (u -> children).size(); i ++) {
		dfs((u -> children)[i], depth + 1);
	}
}

int main() {
	scanf(" %[^\n]", a);
	s.assign(a);
	node * curr = new node;
	node * stat = curr;
	curr -> parent = NULL;
	for(int i = 0; i < s.length(); i ++) {
		if(s[i] == '(') {
			node  * temp = new node;
			curr -> children.push_back(temp);
			temp -> parent = curr;
			curr = temp;
		}
		else if(s[i] == ')') {
			curr = curr -> parent;
		}
		else {
			(curr -> text).push_back(s[i]);
		}
	}
	dfs(stat, -1);
	return 0;
}
